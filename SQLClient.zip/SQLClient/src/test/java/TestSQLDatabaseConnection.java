import org.example.database.SQLDatabaseConnection;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class TestSQLDatabaseConnection {
    @Test
    public void TestSQLDatabaseConnection_GetConnectionString() {
        String connectionString = SQLDatabaseConnection.GetConnectionString();
        assertEquals("jdbc:sqlserver://GBMLVVCSW11933.rbsres01.net:1433;database=MarketsPlatform;user=sa;password=sql101!!;encrypt=true;trustServerCertificate=true;loginTimeout=30;", connectionString);
    }
    @Test
    public void TestSQLDatabaseConnection_TryConnect() {
        try {
            SQLDatabaseConnection.TryConnect();
        } catch (Exception e) {
            fail(e.getMessage());
        }
    }
}
