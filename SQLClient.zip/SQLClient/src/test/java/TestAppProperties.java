import org.example.utils.AppProperties;
import org.junit.Assert;
import org.junit.Test;

public class TestAppProperties {
    @Test
    public void TestAppProperties_GetProperty() {
        String propertyValue = AppProperties.GetProperty("SQLServerName");
        Assert.assertNotNull(propertyValue);
        Assert.assertEquals("GBMLVVCSW11933.rbsres01.net", propertyValue);
    }
}
