import org.example.utils.CsvToSqlServer;
import org.junit.Test;
import org.junit.Assert;


import java.io.IOException;
import java.sql.SQLException;

import static org.junit.Assert.fail;

public class TestCsvToSqlServer {
    @Test
    public void TestCsvToSqlServer_ImportCSVFileToNewTable_HCM012StaffList() throws SQLException, IOException {
        CsvToSqlServer.ImportCSVFileToNewTable("F:\\Markets Platform\\People\\csv\\HCM012_-_Staff_List 26 Feb 2025.csv", "HCM012StaffList");
    }

    @Test
    public void TestCsvToSqlServer_ImportCSVFileToNewTable_SimonPeopleList() throws SQLException, IOException {
        CsvToSqlServer.ImportCSVFileToNewTable("F:\\Markets Platform\\People\\csv\\SimonEaton_-_People_List_teams_costs 28 Feb 2025.csv", "SimonPeopleList");
    }

    @Test
    public void TestCsvToSqlServer_insertRow () {
        String value = "97,000.00";
        String sqlValue = value.replaceAll(",","").replaceAll("(\\d+)(\\.00)","");
        Assert.assertEquals("97000",sqlValue);
    }
}
