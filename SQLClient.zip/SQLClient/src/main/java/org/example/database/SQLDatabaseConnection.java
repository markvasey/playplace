package org.example.database;

import org.example.utils.AppProperties;

import java.sql.*;

public class SQLDatabaseConnection {
    // Connect to your database.
    // Replace server name, username, and password with your credentials
    public static void TryConnect() {

        String connectionUrl = GetConnectionString();

        try (Connection connection = DriverManager.getConnection(connectionUrl);
             Statement statement = connection.createStatement()) {
            // Code here.
            ResultSet resultSet = statement.executeQuery("SELECT name FROM sysobjects");
            while (resultSet.next()) {
                System.out.println(resultSet.getString(1));
            }
        }
        // Handle any errors that may have occurred.
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static String GetConnectionString() {
        Credentials credentials = CredentialsHelper.LoadCredentials("creds.txt");

        String serverName = AppProperties.GetProperty("SQLServerName");
        String port = AppProperties.GetProperty("SQLServerPort");
        String databaseName = AppProperties.GetProperty("SQLDatabaseName");

        return "jdbc:sqlserver://" + serverName + ":" + port + ";"
                        + "database=" + databaseName + ";"
                        + "user=" + credentials.getUsername() + ";"
                        + "password=" + credentials.getPassword() + ";"
                        + "encrypt=true;"
                        + "trustServerCertificate=true;"
                        + "loginTimeout=30;";

    }
}